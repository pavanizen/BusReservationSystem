﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bus.DomainModels.Models
{
    public enum CustomerType
    {
        GovernmentOfficer,
        Student,
        PrivateEmployee,
        Others
    }
}
