﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Bus.DomainModels.Models
{
   public class BusDetails
    {
        [Key]
        public string BusId { get; set; }
        public string BusName { get; set; }

       

        [Required]
        [EnumDataType(typeof(Category))]
        public Category Category { get; set; }
        [Required]
        [Range(1, 30)]
        public int Capacity { get; set; }
        public virtual List<Trip> Trips { get; set; }
    }
}
