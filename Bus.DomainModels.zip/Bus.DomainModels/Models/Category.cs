﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bus.DomainModels.Models
{
   public enum Category
    {
        A_CSemiSleeper,
        A_CSleeper,
        NonA_CSeater

    }
}
