﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Bus.DomainModels.Models
{
    public class Trip
    {
        [Key]
        public int TripID { get; set; }

       

       
        //public DateTime JourneyDate { get; set; }

        //public int NoOfTickets { get; set; }


        [Display(Name = "Available Seats")]
        public bool AvailableSeats { get; set; }

        [Required]
        [ForeignKey("Route")]
        public string RouteID { get; set; }

        [Required]
        [ForeignKey("BusDetails")]
        public string BusID { get; set; }

        //Navigation Properties
        public virtual Route Route { get; set; }
        public virtual BusDetails Bus { get; set; }
        public virtual List<Ticket> Tickets { get; set; }
    }
}
